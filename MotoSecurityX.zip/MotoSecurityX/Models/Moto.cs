﻿namespace MotoSecurityX.Models
{

        public class Moto
        {
            public int Id { get; set; }
            public string Modelo { get; set; }
            public string Placa { get; set; }
            public bool EmUso { get; set; }
            public DateTime DataUltimaRevisao { get; set; }
        }
    }

